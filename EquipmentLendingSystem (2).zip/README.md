# Equipment Lending System
Instructions for running the application.