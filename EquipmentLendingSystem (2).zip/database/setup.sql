
DROP TABLE IF EXISTS users;
CREATE TABLE users (
    username VARCHAR(50) PRIMARY KEY,
    password VARCHAR(100),
    role VARCHAR(30)
);

INSERT INTO users VALUES ('admin1', 'admin123', 'administrator');
INSERT INTO users VALUES ('student1', 'student123', 'student');
INSERT INTO users VALUES ('staff1', 'staff123', 'academic_staff');
INSERT INTO users VALUES ('prostaff1', 'pro123', 'professional_staff');
